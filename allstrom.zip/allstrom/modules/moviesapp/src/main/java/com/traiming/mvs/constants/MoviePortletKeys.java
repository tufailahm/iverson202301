package com.traiming.mvs.constants;

/**
 * @author tufai
 */
public class MoviePortletKeys {

	public static final String MOVIE =
		"com_traiming_mvs_MoviePortlet";

}